{{/*
Shared pod-spec fragments for the migrations subchart's Jobs.

Both the schema-migrations Job (_jobspec.yaml) and the batched-background-migrations
wait Job (_batched-background-migrations-jobspec.yaml) run the same toolbox image
against the same database, so they mount identical config/secret volumes and run the
same init containers. These fragments hold that shared, verbatim boilerplate so the two
Jobs cannot drift. Each is included with `.` (the migrations subchart context), so `$`
resolves to the chart root exactly as it did inline.
*/}}

{{- define "migrations.job.initContainers" -}}
{{- $initImageCfg := include "gitlab.configure.config" .Values | fromYaml -}}
{{- include "gitlab.extraInitContainers" . | nindent 8 }}
{{- include "gitlab.certificates.initContainer" . | nindent 8 }}
        - name: configure
          command: ['sh', '/config/configure']
          image: {{ include "gitlab.configure.image" (dict "root" $ "image" .Values.init.image) | quote }}
          {{- include "gitlab.image.pullPolicy" $initImageCfg | indent 10 }}
          {{- include "gitlab.init.containerSecurityContext" $ | indent 10 }}
          env:
          {{- include "gitlab.timeZone.env" . | nindent 10 }}
          {{- include "gitlab.extraEnv" . | nindent 10 }}
          {{- include "gitlab.extraEnvFrom" (dict "root" $ "local" .) | nindent 10 }}
          volumeMounts:
          {{- include "gitlab.extraVolumeMounts" . | nindent 10 }}
          {{- include "gitlab.psql.ssl.volumeMount" . | nindent 10 }}
          {{- include "gitlab.geo.psql.ssl.volumeMount" . | nindent 10 }}
          - name: migrations-config
            mountPath: /config
            readOnly: true
          - name: init-migrations-secrets
            mountPath: /init-config
            readOnly: true
          - name: migrations-secrets
            mountPath: /init-secrets
            readOnly: false
          resources:
            {{- toYaml .Values.init.resources | nindent 12 }}
{{- end -}}

{{- define "migrations.job.volumeMounts" }}
            - name: migrations-config
              mountPath: '/var/opt/gitlab/templates'
            - name: migrations-secrets
              mountPath: '/etc/gitlab'
              readOnly: true
            - name: migrations-secrets
              mountPath: /srv/gitlab/config/secrets.yml
              subPath: rails-secrets/secrets.yml
            {{- include "gitlab.topologyService.volumeMounts" (dict "context" $ "secretsVolumeName" "migrations-secrets") | nindent 12 }}
            - name: migrations-secrets
              mountPath: /srv/gitlab/config/initial_root_password
              subPath: migrations/initial_root_password
            - name: migrations-secrets
              mountPath: /srv/gitlab/config/gitlab_shared_runners_registration_token
              subPath: migrations/gitlab_shared_runners_registration_token
            {{- if .Values.global.gitlab.license.secret }}
            - name: migrations-secrets
              mountPath: /srv/gitlab/config/Gitlab.gitlab-license
              subPath: migrations/enterprise_license
            {{- end }}
            {{- include "gitlab.extraVolumeMounts" . | nindent 12 }}
            {{- include "gitlab.certificates.volumeMount" . | nindent 12 }}
{{- end -}}

{{- define "migrations.job.volumes" -}}
      {{- include "gitlab.extraVolumes" . | nindent 6 }}
      {{- include "gitlab.psql.ssl.volume" . | nindent 6 }}
      {{- include "gitlab.geo.psql.ssl.volume" . | nindent 6 }}
      - name: migrations-config
        configMap:
          name: {{ template "fullname" . }}
      - name: init-migrations-secrets
        projected:
          defaultMode: 0400
          sources:
          {{ if and (eq $.Values.global.pages.enabled true) (eq $.Values.global.pages.accessControl true) }}
          - secret:
              name: {{ template "oauth.gitlab-pages.secret" . }}
              items:
                - key: {{ template "oauth.gitlab-pages.appIdKey" . }}
                  path: oauth-secrets/gitlab-pages/appid
                - key: {{ template "oauth.gitlab-pages.appSecretKey" . }}
                  path: oauth-secrets/gitlab-pages/appsecret
          - configMap:
              name: {{ template "fullname" . }}
              items:
                - key: pages_redirect_uri
                  path: oauth-secrets/gitlab-pages/redirecturi
          {{- end }}
          - secret:
              name: {{ template "gitlab.rails-secrets.secret" . }}
              items:
                - key: secrets.yml
                  path: rails-secrets/secrets.yml
          {{- include "gitlab.gitaly.clientSecrets" . | nindent 10 }}
          {{- include "gitlab.redis.secrets" (dict "globalContext" $) | nindent 10 }}
          {{- include "gitlab.redisSentinel.secret" $ | nindent 10 }}
          {{- range $.Values.local.psql }}
          {{-   include "gitlab.psql.secret" . | nindent 10 }}
          {{- end }}
          {{- include "gitlab.topologyService.mountSecrets" $ | nindent 10 }}
          {{- if $.Values.global.clickhouse.enabled }}
            {{- include "gitlab.clickhouse.main.secrets" $ | nindent 10 }}
          {{- end }}
          {{- if include "gitlab.geo.secondary" $ }}
          - secret:
              name: {{ template "gitlab.geo.psql.password.secret" . }}
              items:
                - key: {{ template "gitlab.geo.psql.password.key" . }}
                  path: postgres/geo-psql-password
          {{- end }}
          # Object storage secrets - start
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "object_store" "config" $.Values.global.appConfig.object_store) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "artifacts" "config" $.Values.global.appConfig.artifacts) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "lfs" "config" $.Values.global.appConfig.lfs) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "uploads" "config" $.Values.global.appConfig.uploads) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "packages" "config" $.Values.global.appConfig.packages) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "external_diffs" "config" $.Values.global.appConfig.externalDiffs) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "terraform_state" "config" $.Values.global.appConfig.terraformState) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "ci_secure_files" "config" $.Values.global.appConfig.ciSecureFiles) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "agent_plan_content" "config" $.Values.global.appConfig.agentPlanContent) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "ci_catalog_bundles" "config" $.Values.global.appConfig.ciCatalogBundles) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "dependency_proxy" "config" $.Values.global.appConfig.dependencyProxy) | nindent 10 }}
          {{- include "gitlab.appConfig.objectStorage.mountSecrets" (dict "name" "pages" "config" $.Values.global.pages.objectStore) | nindent 10 }}
          # Object storage secrets - end
          - secret:
              name: {{ template "gitlab.migrations.initialRootPassword.secret" . }}
              items:
                - key: {{ template "gitlab.migrations.initialRootPassword.key" . }}
                  path: migrations/initial_root_password
          - secret:
              name: {{ template "gitlab.gitlab-runner.registrationToken.secret" . }}
              optional: true
              items:
                - key: runner-registration-token
                  path: migrations/gitlab_shared_runners_registration_token
          {{- if .Values.global.gitlab.license.secret }}
          - secret:
              name: {{ .Values.global.gitlab.license.secret }}
              items:
                - key: {{ template "gitlab.migrations.license.key" . }}
                  path: migrations/enterprise_license
          {{- end }}
      - name: migrations-secrets
        emptyDir:
          medium: "Memory"
      {{- include "gitlab.certificates.volumes" . | nindent 6 }}
{{- end -}}
