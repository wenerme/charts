{{/*
Expand the name of the chart.
*/}}
{{- define "gitlab-zoekt.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "gitlab-zoekt.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "gitlab-zoekt.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Cluster domain
*/}}
{{- define "gitlab-zoekt.clusterDomain" -}}
{{- $dnsResolver := .Values.gateway.dnsResolver }}
{{- $dnsArr := splitList "." $dnsResolver }}
{{- $arrLen := len $dnsArr }}
{{- join "." (slice $dnsArr (sub $arrLen 2) $arrLen) }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "gitlab-zoekt.labels" -}}
helm.sh/chart: {{ include "gitlab-zoekt.chart" . }}
{{ include "gitlab-zoekt.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "gitlab-zoekt.selectorLabels" -}}
app.kubernetes.io/name: {{ include "gitlab-zoekt.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Gateway selector labels
*/}}
{{- define "gitlab-zoekt.gatewaySelectorLabels" -}}
app.kubernetes.io/name: {{ printf "%s-gateway" (include "gitlab-zoekt.name" .) }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Gateway image
*/}}
{{- define "gitlab-zoekt.gatewayImage" -}}
{{- if .Values.gateway.image.digest }}
{{- printf "%s@%s" .Values.gateway.image.repository .Values.gateway.image.digest }}
{{- else }}
{{- printf "%s:%s" .Values.gateway.image.repository .Values.gateway.image.tag }}
{{- end }}
{{- end}}

{{/*
External Gateway svc name
*/}}
{{- define "gitlab-zoekt.gatewaySvc" -}}
{{- printf "%s-gateway" (include "gitlab-zoekt.fullname" .) }}
{{- end }}

{{/*
External Gateway svc fqdn
*/}}
{{- define "gitlab-zoekt.gatewaySvcFqdn" -}}
{{- include "gitlab-zoekt.gatewaySvc" . }}.{{ .Release.Namespace }}.svc.{{ include "gitlab-zoekt.clusterDomain" . }}
{{- end }}

{{/*
External Gateway svc URL
*/}}
{{- define "gitlab-zoekt.gatewaySvcUrl" -}}
http{{ .Values.gateway.tls.certificate.enabled | ternary "s" "" }}://{{ include "gitlab-zoekt.gatewaySvcFqdn" . }}:{{ .Values.gateway.listen.port }}
{{- end }}

{{/*
Backend svc name
Should be set to gitlab-zoekt.fullname. Otherwise, stateful set's DNS stops working correctly
*/}}
{{- define "gitlab-zoekt.backendSvc" -}}
{{- include "gitlab-zoekt.fullname" . }}
{{- end }}

{{/*
Backend svc fqdn
*/}}
{{- define "gitlab-zoekt.backendSvcFqdn" -}}
{{- include "gitlab-zoekt.backendSvc" . }}.{{ .Release.Namespace }}.svc.{{ include "gitlab-zoekt.clusterDomain" . }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "gitlab-zoekt.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "gitlab-zoekt.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Placeholder template definitions.
These are overridden when this chart is used as a sub-chart of gitlab/gitlab
*/}}
{{- define "gitlab.standardLabels" -}}
{{- end -}}
{{- define "gitlab.commonLabels" -}}
{{- end -}}
{{- define "gitlab.serviceLabels" -}}
{{- end -}}

{{/*
GitLab-aligned extra container templates
These follow the same patterns as the main GitLab chart and are overridden when used as a subchart
*/}}
{{- define "gitlab.extraInitContainers" -}}
{{ tpl (default "" .Values.extraInitContainers) . }}
{{- end -}}

{{- define "gitlab.extraVolumes" -}}
{{ tpl (default "" .Values.extraVolumes) . }}
{{- end -}}

{{- define "gitlab.extraVolumeMounts" -}}
{{ tpl (default "" .Values.extraVolumeMounts) . }}
{{- end -}}

{{- define "gitlab.extraContainers" -}}
{{ tpl (default "" .Values.extraContainers) . }}
{{- end -}}

{{/*
GitLab certificate template stubs - these are overridden by main GitLab chart when used as subchart
*/}}
{{- define "gitlab.certificates.initContainer" -}}
{{- end -}}

{{- define "gitlab.certificates.volumeMount" -}}
{{- end -}}

{{- define "gitlab.certificates.volumes" -}}
{{- end -}}

{{/*
Create the name of the map to use for external deployment gateway
*/}}
{{- define "gitlab-zoekt.configExternalGatewayMapName" -}}
{{- printf "%s-gateway-nginx-conf" (include "gitlab-zoekt.fullname" .) }}
{{- end }}

{{/*
Create the name of the map to use for zoekt gateway
*/}}
{{- define "gitlab-zoekt.configZoektGatewayMapName" -}}
{{- printf "%s-nginx-conf" (include "gitlab-zoekt.fullname" .) }}
{{- end }}

{{- define "gitlab-zoekt.internalApi.secretName" -}}
{{- if empty .Values.indexer.internalApi.secretName }}
  {{- fail "indexer.internalApi.secretName is required and cannot be empty. Please provide the name of the secret containing your GitLab shell secret." -}}
{{- end }}
{{- printf "%s" (tpl .Values.indexer.internalApi.secretName $) -}}
{{- end -}}

{{- define "gitlab-zoekt.internalApi.secretKey" -}}
{{- if empty .Values.indexer.internalApi.secretKey }}
  {{- fail "indexer.internalApi.secretKey is required and cannot be empty. Please provide the key name within the secret that contains the GitLab shell secret value." -}}
{{- end }}
{{- printf "%s" (tpl .Values.indexer.internalApi.secretKey $) -}}
{{- end -}}

{{- define "gitlab-zoekt.internalApi.gitlabUrl" -}}
{{- if empty .Values.indexer.internalApi.gitlabUrl }}
  {{- fail "indexer.internalApi.gitlabUrl is required and cannot be empty. Please provide the internal URL to connect to GitLab." -}}
{{- end }}
{{- printf "%s" (tpl .Values.indexer.internalApi.gitlabUrl $) -}}
{{- end -}}

{{- define "gitlab-zoekt.internalApi.serviceUrl" -}}
{{- if .Values.indexer.internalApi.serviceUrl }}
{{- printf "%s" (tpl .Values.indexer.internalApi.serviceUrl $) -}}
{{- else }}
{{- include "gitlab-zoekt.gatewaySvcUrl" .}}
{{- end -}}
{{- end -}}

{{/*
Template used in NOTES.txt for the default pod name
*/}}
{{- define "gitlab-zoekt.notesDefaultPodName" -}}
{{ printf "%s-0" (include "gitlab-zoekt.backendSvc" .) }}
{{- end }}

{{/*
Common initContainers template for certificates and extra init containers
Used by both deployment and stateful set
*/}}
{{- define "gitlab-zoekt.commonInitContainers" -}}
{{- $certificateInitContainersEnabled := dig "initContainers" "enabled" true .Values.certificates -}}
{{- $hasCertificates := (and $certificateInitContainersEnabled .Values.global .Values.global.certificates .Values.global.certificates.customCAs (gt (len .Values.global.certificates.customCAs) 0)) -}}
{{- $hasExtraInitContainers := .Values.extraInitContainers -}}
{{- if or $hasCertificates $hasExtraInitContainers }}
{{-   if $hasCertificates }}
{{-     include "gitlab.certificates.initContainer" . | nindent 0 }}
{{-   end }}
{{-   if $hasExtraInitContainers }}
{{-     include "gitlab.extraInitContainers" . | nindent 0 }}
{{-   end }}
{{- end -}}
{{- end }}

{{/*
Check if certificate volumes should be added
Returns true if certificates init container will run
*/}}
{{- define "gitlab-zoekt.hasCertificates" -}}
{{- $certificateInitContainersEnabled := dig "initContainers" "enabled" true .Values.certificates -}}
{{- $hasCertificates := (and $certificateInitContainersEnabled .Values.global .Values.global.certificates .Values.global.certificates.customCAs (gt (len .Values.global.certificates.customCAs) 0)) -}}
{{- if $hasCertificates -}}
true
{{- end -}}
{{- end }}