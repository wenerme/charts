{{/* vim: set filetype=mustache: */}}

{{/*
Name of the Webservice HTTPRoute. Shared by the HTTPRoute itself and
any policy resources that target it (for example BackendTrafficPolicy),
so the two can not drift apart.
*/}}
{{- define "webservice.gatewayRoute.name" -}}
{{- printf "%s-gitlab" .Release.Name -}}
{{- end }}

{{/*
Create the fullname, with suffix of deployment.name
Unless `ingress.path: /` or `name: default`

!! to be called from scope of a `deployment.xyz` entry.
*/}}
{{- define "webservice.fullname.withSuffix" -}}
{{- printf "%s-%s" .fullname .name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Returns the secret name for the Secret containing the TLS certificate and key.
Uses `ingress.tls.secretName` first and falls back to `global.ingress.tls.secretName`
if there is a shared tls secret for all ingresses.

It expects a dictionary with two entries:
  `root`: the root context
  `local`: the ingress context
*/}}
{{- define "webservice.tlsSecret" -}}
{{- $defaultName := (dict "secretName" "") -}}
{{- if .root.Values.global.ingress.configureCertmanager -}}
{{-   $postfix := .certmanagerPostfix | default "" }}
{{-   $_ := set $defaultName "secretName" (printf "%s-gitlab-tls%s" .root.Release.Name $postfix) -}}
{{- else -}}
{{-   $_ := set $defaultName "secretName" (include "gitlab.wildcard-self-signed-cert-name" .root) -}}
{{- end -}}
{{- pluck "secretName" .local.tls .root.Values.global.ingress.tls $defaultName | first -}}
{{- end -}}

{{/*
Returns the secret name for the Secret containing the TLS certificate and key for
the smartcard host.
Uses `ingress.tls.secretName` first and falls back to `global.ingress.tls.secretName`
if there is a shared tls secret for all ingresses.
*/}}
{{- define "smartcard.tlsSecret" -}}
{{- $defaultName := (dict "secretName" "") -}}
{{- if $.Values.global.ingress.configureCertmanager -}}
{{- $_ := set $defaultName "secretName" (printf "%s-gitlab-tls-smartcard" $.Release.Name) -}}
{{- else -}}
{{- $_ := set $defaultName "secretName" (include "gitlab.wildcard-self-signed-cert-name" .) -}}
{{- end -}}
{{- coalesce $.Values.ingress.tls.smartcardSecretName (pluck "secretName" $.Values.global.ingress.tls $defaultName | first) -}}
{{- end -}}

{{/*
Returns the workhorse image repository depending on the value of global.edition.

Used to switch the deployment from Enterprise Edition (default) to Community
Edition. If global.edition=ce, returns the Community Edition image repository
set in the Gitlab values.yaml, otherwise returns the Enterprise Edition
image repository.
*/}}
{{- define "workhorse.repository" -}}
{{- if eq "ce" $.Values.global.edition -}}
{{ index $.Values "global" "communityImages" "workhorse" "repository" }}
{{- else -}}
{{ index $.Values "global" "enterpriseImages" "workhorse" "repository" }}
{{- end -}}
{{- end -}}

{{/*
Returns the webservice image depending on the value of global.edition.

Used to switch the deployment from Enterprise Edition (default) to Community
Edition. If global.edition=ce, returns the Community Edition image repository
set in the Gitlab values.yaml, otherwise returns the Enterprise Edition
image repository.
*/}}
{{- define "webservice.image" -}}
{{ coalesce $.Values.image.repository (include "image.repository" .) }}:{{ coalesce .Values.image.tag (include "gitlab.versionTag" . ) }}{{ include "gitlab.image.tagSuffix" . }}
{{- end -}}

{{/*
Returns gomplate section for Workhorse direct object storage configuration.

If consolidated object storage is in use, read the connection YAML
  If provider is AWS, render enabled as true.
*/}}
{{- define "workhorse.object_storage.config" -}}
{%- $supported_providers := coll.Slice "AWS" "AzureRM" "Google" -%}
{%- $connection := coll.Dict "provider" "" -%}
{%- if file.Exists "/etc/gitlab/objectstorage/object_store" %}
  {%- $connection = file.Read "/etc/gitlab/objectstorage/object_store" | strings.TrimSpace | data.YAML -%}
{%- end %}
{%- if has $supported_providers $connection.provider %}
[object_storage]
provider = "{% $connection.provider %}"
{%-   if eq $connection.provider "AWS" %}
{%-     $connection = coll.Merge $connection (coll.Dict "aws_access_key_id" "" "aws_secret_access_key" "" ) %}
# AWS / S3 object storage configuration.
[object_storage.s3]
# access/secret can be blank!
aws_access_key_id = {% $connection.aws_access_key_id | strings.TrimSpace | data.ToJSON %}
aws_secret_access_key = {% $connection.aws_secret_access_key | strings.TrimSpace | data.ToJSON %}
{%-   else if eq $connection.provider "AzureRM" %}
{%-     $connection = coll.Merge $connection (coll.Dict "azure_storage_account_name" "" "azure_storage_access_key" "") %}
# Azure Blob storage configuration.
[object_storage.azurerm]
azure_storage_account_name = {% $connection.azure_storage_account_name | strings.TrimSpace | data.ToJSON %}
azure_storage_access_key = {% $connection.azure_storage_access_key | strings.TrimSpace | data.ToJSON %}
{%-   else if eq $connection.provider "Google" %}
# Google storage configuration.
[object_storage.google]
{% $connection | coll.Omit "provider" | data.ToTOML %}
{%-   end %}
{%- end %}
{{- end -}}

{{/*
Returns the extraEnv keys and values to inject into containers. Allows
pod-level values for extraEnv.

Takes a dict with `local` being the pod-level configuration and `parent`
being the chart-level configuration.

Pod values take precedence, then chart values, and finally global
values.
*/}}
{{- define "webservice.podExtraEnv" -}}
{{- $allExtraEnv := merge (default (dict) .local.extraEnv) (default (dict) .context.Values.extraEnv) .context.Values.global.extraEnv -}}
{{- range $key, $value := $allExtraEnv }}
- name: {{ $key }}
  value: {{ $value | quote }}
{{- end -}}
{{- end -}}

{{/*
Output a .spec.selector YAML section

To be consumed by: Deployment and PodDisruptionBudget
*/}}
{{- define "webservice.spec.selector" -}}
matchLabels:
  app: {{ template "name" $ }}
  release: {{ $.Release.Name }}
  {{ template "webservice.labels" . | nindent 2 }}
{{- end -}}

{{/*
Output labels specifically for webservice
*/}}
{{- define "webservice.labels" -}}
gitlab.com/webservice-name: {{ .name }}
{{- end -}}

{{/*
Returns a list of _common_ labels to be shared across all
Webservice deployments and other shared objects.
*/}}
{{- define "webservice.commonLabels" -}}
{{- $commonLabels := default (dict) .common.labels -}}
{{- if $commonLabels }}
{{-   range $key, $value := $commonLabels }}
{{ $key }}: {{ $value | quote }}
{{-   end }}
{{- end -}}
{{- end -}}

{{/*
Returns a list of _pod_ labels to be shared across all
Webservice deployments.
*/}}
{{- define "webservice.podLabels" -}}
{{- range $key, $value := .pod.labels }}
{{ $key }}: {{ $value | quote }}
{{- end }}
{{- end -}}

{{/*
Returns the extraEnv keys and values to inject into containers.

Global values will override any chart-specific values.
*/}}
{{- define "webservice.extraEnv" -}}
{{- $allExtraEnv := merge (default (dict) .local.extraEnv) .global.extraEnv -}}
{{- range $key, $value := $allExtraEnv }}
- name: {{ $key }}
  value: {{ $value | quote }}
{{- end -}}
{{- end -}}

{{/*

*/}}
{{/*
Defines a volume containing all public host SSH keys, fingerprints of which will become available
under /help/instance_configuration for users to be able to verify the server

It expects a dictionary with three entries:
- `local` which contains sshHostKeys configuration of a single webservice Deployment
- `Release` being a copy of .Release
- `Values` being a copy of .Values

The `Release` and `Values` keys are needed because of the usage of the
`gitlab.gitlab-shell.hostKeys.secret` helper.
*/}}
{{- define "webservice.sshHostKeys.volume" -}}
- name: {{ .local.sshHostKeys.mountName }}
  secret:
    secretName: {{ template "gitlab.gitlab-shell.hostKeys.secret" . }}
    items:
    {{- range .local.sshHostKeys.types }}
    - key: ssh_host_{{ . }}_key.pub
      path: ssh_host_{{ . }}_key.pub
    {{- end -}}
{{- end -}}

{{/*
Return the webservice TLS secret name
*/}}
{{- define "webservice.tls.secret" -}}
{{- default (printf "%s-webservice-tls" .Release.Name) $.Values.tls.secretName | quote -}}
{{- end -}}

{{/*
Return the webservice-metrics TLS secret name.
*/}}
{{- define "webservice-metrics.tls.secret" -}}
{{- $.Values.metrics.tls.secretName | default (include "webservice.tls.secret" .) }}
{{- end -}}

{{/*
Return whether the webservice has TLS for metrics enabled.
*/}}
{{- define "webservice-metrics.tls.enabled" -}}
{{- if hasKey $.Values.metrics.tls "enabled" }}
{{-   $.Values.metrics.tls.enabled }}
{{- else }}
{{-   $.Values.tls.enabled }}
{{- end }}
{{- end -}}

{{/*
Return the Workhorse TLS Secret name
*/}}
{{- define "workhorse.tls.secret" -}}
{{- default (printf "%s-workhorse-tls" .Release.Name) $.Values.workhorse.tls.secretName | quote -}}
{{- end -}}

{{/*
Return whether the Workhorse exporter has TLS enabled.
*/}}
{{- define "workhorse.monitoring.exporter.tls.enabled" -}}
{{- if hasKey $.Values.workhorse.monitoring.exporter.tls "enabled" }}
{{-   $.Values.workhorse.monitoring.exporter.tls.enabled }}
{{- else }}
{{-   $.Values.global.workhorse.tls.enabled }}
{{- end }}
{{- end -}}


{{/*
Return the workhorse redis configuration.
*/}}
{{- define "workhorse.redis.config" -}}
{{- if $.Values.global.redis.workhorse }}
{{-   $_ := set $ "redisConfigName" "workhorse" }}
{{- end }}
{{- include "gitlab.redis.selectedMergedConfig" . -}}
[redis]
DB = {{ .redisMergedConfig.database }}
{{- if not .redisMergedConfig.sentinels }}
{{- $userinfo := "" }}
{{- if .redisMergedConfig.user }}
{{- $userinfo = printf "%s@" .redisMergedConfig.user }}
{{- end }}
URL = "{{ template "gitlab.redis.scheme" $ }}://{{ $userinfo }}{{ template "gitlab.redis.host" $ }}:{{ template "gitlab.redis.port" $ }}"
{{- else }}
SentinelMaster = "{{ template "gitlab.redis.host" $ }}"
Sentinel = [ {{ template "gitlab.redis.workhorse.sentinel-list" $ }} ]
{{- end }}
{{- if .redisMergedConfig.password.enabled }}
{{-   $passwordPath := printf "%s-password" (default "redis" .redisConfigName) }}
Password = {% file.Read "/etc/gitlab/redis/{{ $passwordPath }}" | strings.TrimSpace | data.ToJSON %}
{{- end }}
{{- if .redisMergedConfig.sentinelAuth.enabled }}
SentinelPassword = {% file.Read "/etc/gitlab/redis-sentinel/redis-sentinel-password" | strings.TrimSpace | data.ToJSON %}
{{- end }}
{{- include "gitlab.workhorse.redis.tls" . }}
{{- include "gitlab.workhorse.sentinel.tls" . }}
{{- $_ := set . "redisConfigName" "" }}
{{- end -}}

{{/*
Return the bash setup commands for redis secrets.
*/}}
{{- define "workhorse.redis.secret-setup" -}}
{{- if $.Values.global.redis.workhorse -}}
{{-   $_ := set $ "redisConfigName" "workhorse" }}
{{- end -}}
{{- include "gitlab.redis.selectedMergedConfig" . -}}
{{- if .redisMergedConfig.password.enabled -}}
{{-   $passwordPath := printf "%s-password" (default "redis" .redisConfigName) -}}
mkdir -p /init-secrets-workhorse/redis
cp -v -r -L /init-config/redis/{{ $passwordPath }} /init-secrets-workhorse/redis/
{{- end -}}
{{- if .redisMergedConfig.sentinelAuth.enabled }}
mkdir -p /init-secrets-workhorse/redis-sentinel
cp -v -r -L /init-config/redis-sentinel/redis-sentinel-password /init-secrets-workhorse/redis-sentinel/
{{- end -}}
{{- if eq (default "redis" .redisMergedConfig.scheme) "rediss" }}
{{-   $redisTLS := .redisMergedConfig.redisTLS | default (dict) -}}
{{-   if $redisTLS }}
mkdir -p /init-secrets-workhorse/redis
{{-     if (kindIs "map" $redisTLS.caFile) }}
cp -v -r -L /init-config/redis/{{ $redisTLS.caFile.key }} /init-secrets-workhorse/redis/
{{-     end }}
{{-    if (kindIs "map" $redisTLS.cert) }}
cp -v -r -L /init-config/redis/{{ $redisTLS.cert.key }} /init-secrets-workhorse/redis/
{{-     end }}
{{-     if (kindIs "map" $redisTLS.key) }}
cp -v -r -L /init-config/redis/{{ $redisTLS.key.key }} /init-secrets-workhorse/redis/
{{-     end }}
{{-   end }}
{{- end }}
{{- $sentinelTLS := .redisMergedConfig.sentinelTLS | default (dict) -}}
{{- if $sentinelTLS.enabled }}
{{-   if $sentinelTLS }}
mkdir -p /init-secrets-workhorse/redis-sentinel
{{-     if (kindIs "map" $sentinelTLS.caFile) }}
cp -v -r -L /init-config/redis-sentinel/{{ $sentinelTLS.caFile.key }} /init-secrets-workhorse/redis-sentinel/
{{-     end }}
{{-     if (kindIs "map" $sentinelTLS.cert) }}
cp -v -r -L /init-config/redis-sentinel/{{ $sentinelTLS.cert.key }} /init-secrets-workhorse/redis-sentinel/
{{-     end }}
{{-     if (kindIs "map" $sentinelTLS.key) }}
cp -v -r -L /init-config/redis-sentinel/{{ $sentinelTLS.key.key }} /init-secrets-workhorse/redis-sentinel/
{{-     end }}
{{-   end }}
{{- end }}
{{- $_ := set . "redisConfigName" "" }}
{{- end -}}
