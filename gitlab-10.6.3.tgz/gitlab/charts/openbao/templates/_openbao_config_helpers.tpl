{{/*
Helpers related to rendering the OpenBao configuration JSON.
https://openbao.org/docs/configuration/
*/}}

{{/*
Return PostgreSQL configuration as yaml.

This is a hook to be overriden by the GitLab chart to easily override
this information.
*/}}
{{- define "openbao.postgresql.configuration" -}}
{{ toYaml .Values.config.storage.postgresql.connection }}
{{- end -}}

{{/*
Render PostgreSQL storage configuration.
*/}}
{{- define "openbao.storage.postgresql" -}}
{{- $psql := dict "connection_url" (include "openbao.storage.postgresql.connectionUrl" .) -}}
{{- with .Values.config.storage.postgresql -}}
  {{- with .table -}}
  {{ $_ := set $psql "table" . -}}
  {{- end -}}
  {{- with .haTable -}}
  {{ $_ := set $psql "ha_table" . -}}
  {{- end -}}
  {{- with .skipCreateTable -}}
  {{ $_ := set $psql "skip_create_table" . -}}
  {{- end -}}
  {{- with .maxConnectRetries -}}
  {{ $_ := set $psql "max_connect_retries" . -}}
  {{- end -}}
  {{- with .maxIdleConnections -}}
  {{ $_ := set $psql "max_idle_connections" . -}}
  {{- end -}}
  {{- with .maxParallel -}}
  {{ $_ := set $psql "max_parallel" . -}}
  {{- end -}}
  {{- with (include "openbao.storage.postgresql.transactionMaxParallel" .) -}}
  {{ $_ := set $psql "transaction_max_parallel" (int .) -}}
  {{- end -}}
  {{- with .haEnabled -}}
  {{ $_ := set $psql "ha_enabled" . -}}
  {{- end -}}
{{- end -}}
{{- dict "postgresql" $psql | toPrettyJson -}}
{{- end -}}

{{/*
Return the PostgreSQL transaction_max_parallel value, or nothing to keep the
OpenBao default.

Transactions must use fewer connections than max_parallel, so that the HA lock
renewal, the lock checks before commits and the keyring writes always get one.
Otherwise, a burst of requests can hold every connection, and the active node
loses its HA lock.

When unset, it defaults to maxParallel minus 2, and at least 2. When maxParallel
is also unset, OpenBao's defaults already leave room (64 transactions out of 128
connections).

It's never below 2: some code paths start a transaction while holding another,
such as a lease tidy revoking a database engine lease from inside its scan.
Waiting for a transaction never times out, so with a single one they would hang
forever. OpenBao itself never derives a limit below 2 either.

Takes .Values.config.storage.postgresql as context.
*/}}
{{- define "openbao.storage.postgresql.transactionMaxParallel" -}}
{{- $maxParallel := int (.maxParallel | default 128) -}}
{{- $transactionMaxParallel := 0 -}}
{{- if .transactionMaxParallel -}}
  {{- $transactionMaxParallel = int .transactionMaxParallel -}}
{{- else if .maxParallel -}}
  {{- if lt $maxParallel 3 -}}
    {{- fail (printf "config.storage.postgresql.maxParallel (%d) must be at least 3, so that the HA lock renewal always gets a connection, and nested transactions don't hang." $maxParallel) -}}
  {{- end -}}
  {{- $transactionMaxParallel = max 2 (sub $maxParallel 2) | int -}}
{{- end -}}
{{- if $transactionMaxParallel -}}
  {{- if ge $transactionMaxParallel $maxParallel -}}
    {{- fail (printf "config.storage.postgresql.transactionMaxParallel (%d) must be lower than config.storage.postgresql.maxParallel (%d), so that the HA lock renewal always gets a connection." $transactionMaxParallel $maxParallel) -}}
  {{- end -}}
  {{- $transactionMaxParallel -}}
{{- end -}}
{{- end -}}

{{/*
Render PostgreSQL connection URL.

The password is not contained in this URL, and must be configured via environment variables.
*/}}
{{- define "openbao.storage.postgresql.connectionUrl" -}}
{{- $psqlConfig := (include "openbao.postgresql.configuration" . | fromYaml) }}
{{- with $psqlConfig }}
  {{- $connectionUrl := printf "postgres://%s@%s:%d/%s?" .username .host (.port | int) .database -}}
  {{- with .keepalives -}}
  {{-   $connectionUrl = printf "%s&keepalives=%d" $connectionUrl (. | int) -}}
  {{- end -}}
  {{- with .keepalivesIdle -}}
  {{-   $connectionUrl = printf "%s&keepalives_idle=%d" $connectionUrl (. | int) -}}
  {{- end }}
  {{- with .keepalivesInterval -}}
  {{-   $connectionUrl = printf "%s&keepalives_interval=%d" $connectionUrl (. | int) -}}
  {{- end -}}
  {{- with .keepalivesCount -}}
  {{-   $connectionUrl = printf "%s&keepalives_count=%d" $connectionUrl (. | int) -}}
  {{- end -}}
  {{- with .connectTimeout -}}
  {{-   $connectionUrl = printf "%s&connect_timeout=%d" $connectionUrl (. | int) -}}
  {{- end -}}
  {{- with .tcpUserTimeout -}}
  {{-   $connectionUrl = printf "%s&tcp_user_timeout=%d" $connectionUrl (. | int) -}}
  {{- end -}}
  {{- with .sslMode -}}
  {{-   $connectionUrl = printf "%s&sslmode=%s" $connectionUrl . -}}
  {{- end -}}
  {{- $connectionUrl -}}
{{- end -}}
{{- end -}}


{{/*
Pass metadata to Pod. Needed for self labeling.
*/}}
{{- define "openbao.serviceRegistration.config" -}}
"service_registration": {
  "kubernetes": {}
}
{{- end }}

{{/*
Render active TCP listener configuration.
*/}}
{{- define "openbao.listener.config" -}}
{{- $listeners := list -}}
{{/* Default listener */}}
{{- with .Values.config -}}
{{-   $defaultListener := dict "tls_disable" .tlsDisable -}}
{{-   if not .tlsDisable -}}
{{-     $_ := set $defaultListener "tls_cert_file" "/srv/openbao/tls/tls.crt" -}}
{{-     $_ := set $defaultListener "tls_key_file" "/srv/openbao/tls/tls.key" -}}
{{-   end -}}
{{-   $_ := set $defaultListener "address" (printf ":%d" (.apiPort | int)) -}}
{{-   $_ := set $defaultListener "max_request_size" (.maxRequestSize) -}}
{{-   $_ := set $defaultListener "max_request_json_memory" (.maxRequestJsonMemory) -}}
{{-   with .xForwardedFor -}}
{{-     $addrs := compact .authorizedAddrs -}}
{{-     if $addrs -}}
{{-       $_ := set $defaultListener "x_forwarded_for_authorized_addrs" (join "," $addrs) -}}
{{-       $_ := set $defaultListener "x_forwarded_for_hop_skips" .hopSkips -}}
{{-       $_ := set $defaultListener "x_forwarded_for_reject_not_present" .rejectNotPresent -}}
{{-       $_ := set $defaultListener "x_forwarded_for_reject_not_authorized" .rejectNotAuthorized -}}
{{-     end -}}
{{-   end -}}
{{-   $listeners = append $listeners (dict "tcp" $defaultListener) -}}
{{- end -}}
{{/* Metrics listener */}}
{{- with .Values.config.metricsListener -}}
{{-   if .enabled -}}
{{-     $metricsListener := dict "tls_disable" .tlsDisable -}}
{{-     if not .tlsDisable -}}
{{-       $_ := set $metricsListener "tls_cert_file" "/srv/openbao/tls/tls.crt" -}}
{{-       $_ := set $metricsListener "tls_key_file" "/srv/openbao/tls/tls.key" -}}
{{-     end -}}
{{-     $_ := set $metricsListener "address" (printf ":%d" (.port | int)) -}}
{{-     $_ := set $metricsListener "telemetry" (dict "unauthenticated_metrics_access" .unauthenticatedMetricsAccess) -}}
{{-     $_ := set $metricsListener "max_request_size" ($.Values.config.maxRequestSize) -}}
{{-     $_ := set $metricsListener "max_request_json_memory" ($.Values.config.maxRequestJsonMemory) -}}
{{-     $listeners = append $listeners (dict "tcp" $metricsListener) -}}
{{-   end -}}
{{- end -}}
{{- toPrettyJson $listeners -}}
{{- end -}}

{{- define "openbao.telemetry.config" -}}
{{- with .Values.config.telemetry -}}
{{-   if .enabled }}
{{-     $prefix := .metricsPrefix -}}
{{-     range .prefixFilter -}}
{{-       if and (not (hasPrefix "+" .)) (not (hasPrefix "-" .)) -}}
{{-         fail (printf "OpenBao: config.telemetry.prefixFilter entry '%s' must start with '+' or '-'." .) -}}
{{-       end -}}
{{-       if $prefix -}}
{{-         if not (or (hasPrefix (printf "+%s." $prefix) .) (hasPrefix (printf "-%s." $prefix) .)) -}}
{{-           fail (printf "OpenBao: config.telemetry.prefixFilter entry '%s' must be '+%s' or '-%s' followed by '.' and a metric path." . $prefix $prefix) -}}
{{-         end -}}
{{-       end -}}
{{-     end -}}
{{-     $tele := dict "disable_hostname" .disableHostname -}}
{{-     $_ := set $tele "prometheus_retention_time" .prometheusRetentionTime -}}
{{-     $_ := set $tele "metrics_prefix" .metricsPrefix -}}
{{-     $_ := set $tele "usage_gauge_period" .usageGaugePeriod -}}
{{-     $_ := set $tele "num_lease_metrics_buckets" .numLeaseMetricsBuckets -}}
{{-     $_ := set $tele "prefix_filter" .prefixFilter -}}
{{-     toPrettyJson $tele -}}
{{-   end }}
{{- end }}
{{- end }}

{{- define "openbao.seal.config" -}}
{{- $staticConf := .Values.config.unseal.static | default dict -}}
{{- $awskmsConf := .Values.config.unseal.awskms | default dict -}}
{{- $unsealMethods := list
    ($staticConf.enabled | default false)
    ($awskmsConf.enabled | default false)
-}}
{{- $enabledMethods := without $unsealMethods false -}}
{{- $conf := dict -}}
{{- if $staticConf.enabled | default false -}}
{{-   if empty $staticConf.currentKeyId -}}
{{-     fail "OpenBao: config.unseal.static.currentKeyId is required when static unsealing is enabled." -}}
{{-   end -}}
{{-   if empty $staticConf.currentKey -}}
{{-     fail "OpenBao: config.unseal.static.currentKey is required when static unsealing is enabled." -}}
{{-   end -}}
{{-   $static := dict "current_key_id" $staticConf.currentKeyId "current_key" (printf "file://%s" $staticConf.currentKey) -}}
{{-   if $staticConf.previousKeyId -}}
{{-     if empty $staticConf.previousKey -}}
{{-       fail "OpenBao: config.unseal.static.previousKey is required when previousKeyId is set." -}}
{{-     end -}}
{{-     $_ := set $static "previous_key_id" $staticConf.previousKeyId -}}
{{-     $_ := set $static "previous_key" (printf "file://%s" $staticConf.previousKey) -}}
{{-   else if $staticConf.previousKey -}}
{{-     fail "OpenBao: config.unseal.static.previousKeyId is required when previousKey is set." -}}
{{-   end -}}
{{-   $_ := set $conf "static" $static -}}
{{- end -}}
{{- if $awskmsConf.enabled | default false -}}
{{-   if empty $awskmsConf.kmsKeyId -}}
{{-     fail "OpenBao: config.unseal.awskms.kmsKeyId is required when AWS KMS unsealing is enabled." -}}
{{-   end -}}
{{-   $awskms := dict "kms_key_id" $awskmsConf.kmsKeyId -}}
{{-   if not (empty $awskmsConf.region) -}}
{{-     $_ := set $awskms "region" $awskmsConf.region -}}
{{-   end -}}
{{-   if not (empty $awskmsConf.endpoint) -}}
{{-     $_ := set $awskms "endpoint" $awskmsConf.endpoint -}}
{{-   end -}}
{{-   $_ := set $conf "awskms" $awskms -}}
{{- end -}}
{{- toPrettyJson $conf }}
{{- end }}

{{- define "openbao.initialize.config" -}}
{{- if .Values.config.initialize.enabled }}
{{- tpl .Values.initializeTpl . | fromYamlArray | toPrettyJson }}
{{- end }}
{{- end }}

{{- define "openbao.audit.config" -}}
{{- tpl .Values.auditTpl . | fromYamlArray | toPrettyJson }}
{{- end -}}

{{- define "openbao.logging.config" -}}
{{- with .Values.config -}}
"log_level": {{ .logLevel | quote }},
{{- /* OpenBao has no "off" request log level. It warns on "off" and logs no requests when the key is unset. */}}
{{- if and .logRequestsLevel (ne .logRequestsLevel "off") }}
"log_requests_level": {{ .logRequestsLevel | quote }},
{{- end }}
"log_format": {{ .logFormat | quote }}
{{- end -}}
{{- end -}}
